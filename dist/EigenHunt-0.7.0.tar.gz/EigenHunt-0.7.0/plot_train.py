from rl_zoo3.plots.plot_train import plot_train

if __name__ == "__main__":
    plot_train()